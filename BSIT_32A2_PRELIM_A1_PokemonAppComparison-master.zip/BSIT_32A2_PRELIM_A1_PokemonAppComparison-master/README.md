Add comparison here

blah blah blah
